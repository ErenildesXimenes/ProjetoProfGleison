import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

String ConteudoTable= "ConteudoTable";
String idColumn= "idColumn";
String TituloColumn= "TituloColumn";
String AutorColumn= "AutorColumn";
String TextoColumn= "TextoColumn";
String ImgColumn= "ImgColumn";
String VideoColumn= "VideoColumn";
String TipoConteudoColumn="TipoConteudoColumn";

class ConteudoHelper {
  static final ConteudoHelper _instance = ConteudoHelper.internal();
  factory ConteudoHelper() => _instance;
  ConteudoHelper.internal();

  Database _db;

  Future<Database> get db async{
    if (_db!= null){
      return _db;
    }else {
      _db= await initDb();
      return _db;
    }
  }
Future<Database> initDb() async {
    final dataBasesPath= await getDatabasesPath();
    final path= join(dataBasesPath, "Conteudo2.db");
    
    return await openDatabase(path,version: 1,onCreate: (Database db, int newerVersion) async{
      await db.execute(
        "CREATE TABLE $ConteudoTable($idColumn INT PRYMARY KEY, $TituloColumn TEXT, $AutorColumn TEXT, $TextoColumn TEXT, $ImgColumn TEXT, $VideoColumn TEXT, $TipoConteudoColumn TEXT)"
      );
    });
}
Future<Conteudo> SaveConteudo(Conteudo conteudo) async {
    Database dbConteudo= await db;
    conteudo.id =  await dbConteudo.insert(ConteudoTable, conteudo.toMap());
    return conteudo;
}
Future<Conteudo> GetConteudo(int id) async{
    Database dbConteudo= await db;
    List<Map> maps= await dbConteudo.query(ConteudoTable,
      columns: [idColumn, TituloColumn,TextoColumn,ImgColumn,VideoColumn,AutorColumn,TipoConteudoColumn],
      where: "$idColumn = ?",
      whereArgs: [id]);
    if(maps.length > 0){
      return Conteudo.fromMap(maps.first);
    }else {
      return null;
    }
}
Future<int> DeleteConteudo(int id) async {
    Database dbConteudo = await db;
    return await dbConteudo.delete(ConteudoTable,where: "$idColumn = ?", whereArgs: [id]);

}
Future<int> UpdateConteudo(Conteudo conteudo) async {
  Database dbConteudo = await db;
  return await dbConteudo.update(ConteudoTable, conteudo.toMap(), where: "$idColumn = ?",whereArgs: [conteudo.id]);

}
Future<List>GetAllConteudos() async {
    Database dbConteudo = await db;
    List listmap = await dbConteudo.rawQuery("SELECT * FROM $ConteudoTable");
    List<Conteudo> listConteudo = List();
    for(Map m in listmap){
      listConteudo.add(Conteudo.fromMap(m));
    }
    return listConteudo;
}
Future<int>GetNumber() async {
  Database dbConteudo = await db;
  return Sqflite.firstIntValue(await dbConteudo.rawQuery("SELECT COUNT(*) FROM $ConteudoTable"));

}
Future Close() async{
  Database dbConteudo = await db;
  dbConteudo.close();


}
}

class Conteudo {
  String Titulo;
  String Autor;
  String Texto;
  String Img;
  String Video;
  int id;
  String TipoConteudo;
  Conteudo();

  Conteudo.fromMap(Map map){
    id= map[idColumn];
    Titulo= map[TituloColumn];
    Autor= map[AutorColumn];
    Texto=map[TextoColumn];
    Img=map[ImgColumn];
    Video=map[VideoColumn];
    TipoConteudo=map[TipoConteudoColumn];

  }
  Map toMap(){
    Map<String, dynamic> map={
      TituloColumn:Titulo,
      AutorColumn:Autor,
      TextoColumn:Texto,
      ImgColumn:Img,
      VideoColumn:Video,
      TipoConteudoColumn:TipoConteudo
    };
    if (id !=null){
      map[idColumn]=id;
    }
    return map;
  }

  @override
  String toString() {
    return "Conteudo(Titulo: $Titulo, Autor: $Autor, Texto: $Texto, Tipo: $TipoConteudo)";
  }

}