import 'dart:convert';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:helpapp/pages/ConteudoDetalhes.dart';
import 'package:helpapp/pages/ConteudoPage.dart';
import 'models/item.dart';

void main() {
  runApp(MaterialApp(
    home: WidgetLogin(),
  ));
}


class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primaryColor: Colors.green,
      ),
      home: Conteudo(),
    );
  }
}

class WidgetLogin extends StatefulWidget {
  @override
  _WidgetLoginState createState() => _WidgetLoginState();
}

class _WidgetLoginState extends State<WidgetLogin> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      //https://github.com/genilsonalvessistemas/apphelp
      //header login
      body: Container(
        width: double.infinity,
        decoration: BoxDecoration(
            gradient: LinearGradient(begin: Alignment.topCenter, colors: [
              Colors.green[900],
              Colors.green[800],
              Colors.green[400]
            ])),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: <Widget>[
            SizedBox(
              height: 70,
            ),
            Padding(
              padding: EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: <Widget>[
                  Text(
                    "Login",
                    style: TextStyle(color: Colors.white, fontSize: 40),
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  Text(
                    "Bem vindo de volta",
                    style: TextStyle(color: Colors.white, fontSize: 18),
                  ),
                ],
              ),
            ),
            SizedBox(height: 10),

            //box branca
            Expanded(
              child: Container(
                decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(60),
                        topRight: Radius.circular(60))),
                child: SingleChildScrollView(
                  child: Padding(
                    padding: EdgeInsets.all(35),
                    child: Column(
                      children: <Widget>[
                        SizedBox(
                          height: 25,
                        ),

                        //formulario
                        Container(
                          child: Column(
                            children: <Widget>[
                              Container(
                                padding: EdgeInsets.all(20),
                                decoration: BoxDecoration(
                                    border: Border(
                                        bottom: BorderSide(
                                            color: Colors.grey[200]))),
                                child: TextField(
                                  decoration: InputDecoration(
                                      labelText: "E-mail",
                                      labelStyle: TextStyle(color: Colors.grey),
                                      border: InputBorder.none),
                                ),
                              ),
                              Container(
                                padding: EdgeInsets.all(20),
                                decoration: BoxDecoration(
                                    border: Border(
                                        bottom: BorderSide(
                                            color: Colors.grey[200]))),
                                child: TextField(
                                  obscureText: true,
                                  decoration: InputDecoration(
                                      labelText: "Senha",
                                      labelStyle: TextStyle(color: Colors.grey),
                                      border: InputBorder.none),
                                ),
                              ),
                            ],
                          ),
                        ),

                        SizedBox(height: 30),

                        //esqueceu sua senha
                        Text(
                          "Esqueceu sua senha?",
                          style: TextStyle(color: Colors.grey),
                        ),
                        SizedBox(height: 30),

                        //botao login
                        ButtonTheme(
                          height: 60,
                          child: RaisedButton(
                            onPressed: (){
                              _ShowHome();

                            },
                            child: Text(
                              "Entrar",
                              style: TextStyle(color: Colors.amberAccent),
                            ),
                          ),
                        )
                      ],
                    ),
                  ),
                ),
              ),
            )
          ],
        ),
      ),
    );
  }
  Future<void> _ShowHome({Conteudo conteudo}) async {
    await  Navigator.push(context, MaterialPageRoute(builder: (context)=> ConteudoPage()));

  }
}
class Conteudo extends StatefulWidget {
  var itens = new List<Item>();
  Conteudo() {
    itens=[];
    itens.add(Item(titulo: "Depressão na escola", autor: "ADM", assunto: 1, done: true));
    itens.add(Item(titulo: "Ansiedade na escola", autor: "ADM", assunto: 2, done: false));
    itens.add(Item(titulo: "Fobia na escola", autor: "ADM", assunto: 3, done: true));
    itens.add(Item(titulo: "Pressão na escola", autor: "ADM", assunto: 4, done: false));


  }
  @override
  _ConteudoState createState() => _ConteudoState();
}

class _ConteudoState extends State<Conteudo> {
  var Titulo = TextEditingController();
  var autor= TextEditingController();
  void add(){
    setState(() {
      widget.itens.add(Item(titulo: Titulo.text, autor: autor.text, assunto: 1, done: false ));
      Titulo.text="";
      autor.text="";
    });
  }
  Future load() async {
    var prefs= await SharedPreferences.getInstance();
    var data= prefs.getString('data');
    if (data != null) {
      Iterable decoded = jsonDecode(data);
      List<Item> result= decoded.map((x) => Item.fromJson(x)).toList();
      setState(() {
        widget.itens= result;
      });
    }

  }
  _ConteudoState(){
    load();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: TextFormField(
          controller: Titulo,
          decoration: InputDecoration(
            labelText: "Titulo da Tarefa",
          ),
        ),
      ),
      body: ListView.builder(
        itemCount: widget.itens.length,
        itemBuilder: (ctxt, index){
          final item = widget.itens[index];
          return CheckboxListTile(
            title: Text(item.titulo),
            key: Key(item.titulo),
            value: item.done,
            onChanged: (value){
              setState(() {
                item.done=value;
              });
            },
          );

        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: add,
        child: Icon(Icons.add),
        backgroundColor: Colors.green[600],
      ),
    );
  }
}




