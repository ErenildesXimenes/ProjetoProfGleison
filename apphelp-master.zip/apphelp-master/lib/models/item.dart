class Item {
  String titulo;
  bool done;
  int assunto;
  String autor;

  Item({this.titulo, this.done, this.assunto, this.autor});

  Item.fromJson(Map<String, dynamic> json) {
    titulo = json['titulo'];
    done = json['done'];
    assunto = json['Assunto'];
    autor = json['Autor'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['titulo'] = this.titulo;
    data['done'] = this.done;
    data['Assunto'] = this.assunto;
    data['Autor'] = this.autor;
    return data;
  }
}