import 'dart:io';

import 'package:flutter/material.dart';
import 'package:helpapp/Helpers/Conteudo_Helper.dart';

class ConteudoDetalhes extends StatefulWidget {

  final Conteudo conteudoDetalhe;

  ConteudoDetalhes({this.conteudoDetalhe});
  @override
  _ConteudoDetalhesState createState() => _ConteudoDetalhesState();
}

class _ConteudoDetalhesState extends State<ConteudoDetalhes> {

  final _tituloControler= TextEditingController();
  final _TextoControler= TextEditingController();
  final _TipoControler= TextEditingController();

  Conteudo _editarConteudo;
  bool conteudoEditado= false;

  @override
  void initState() {
    super.initState();
    if (widget.conteudoDetalhe == null){
      _editarConteudo = new Conteudo();
    }else{
      _editarConteudo = Conteudo.fromMap(widget.conteudoDetalhe.toMap());
      _tituloControler.text=_editarConteudo.Titulo;
      _TextoControler.text=_editarConteudo.Texto;
    }
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.green[600],
        title: Text(_editarConteudo.Titulo ?? "Nova Postagem"),
        centerTitle: true,
      ),

      body: SingleChildScrollView(
        padding: EdgeInsets.all(10.0),
        child: Column(
          children: <Widget>[
            GestureDetector(
              child: Container(
                width: 140,
                height: 140,
                decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    image: DecorationImage(
                        image: _editarConteudo.Img != null ?
                        FileImage(File(_editarConteudo.Img)) :
                        AssetImage("images/person.png")
                    )
                ),
              ),
            ),
            TextField(
              controller: _tituloControler,
              decoration: InputDecoration(labelText: "Titulo"),
              onChanged: (text){
                conteudoEditado = true;
                setState(() {
                  _editarConteudo.Titulo= text;
                });
              },
            ),
            TextField(
              controller: _TextoControler,
              decoration: InputDecoration(labelText: "Texto"),
            ),
          ],
        ),
      ),
    );
  }


}
