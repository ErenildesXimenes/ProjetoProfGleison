import 'dart:io';

import 'package:flutter/material.dart';
import 'package:helpapp/Helpers/Conteudo_Helper.dart';
import 'package:helpapp/pages/ConteudoDetalhes.dart';

class ConteudoPage extends StatefulWidget {
  @override
  _ConteudoPageState createState() => _ConteudoPageState();
}

class _ConteudoPageState extends State<ConteudoPage> {

  ConteudoHelper helper= ConteudoHelper();
  List<Conteudo> conteudos = List();


  @override
  void initState() {
    super.initState();
    /*Conteudo c= Conteudo();
    c.Titulo="Panico";
    c.Texto="O Panico é um problema";
    helper.SaveConteudo(c);*/


    _getAll();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Conteudo"),
        backgroundColor: Colors.green[600],
        centerTitle: true,
      ),
      backgroundColor: Colors.green[100],

      body: ListView.builder(
          padding: EdgeInsets.all(10.0) ,
          itemCount: conteudos.length,
          itemBuilder: (context, index){
            return _ConteudoCard(context, index);

          }
      ),
    );
  }
  Widget _ConteudoCard(BuildContext context, int index){
    return GestureDetector(
      child: Card(
        child: Padding(
          padding: EdgeInsets.all(10.0),
          child: Row(
            children: <Widget>[
              Container(
                width: 80,
                height: 80,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  image: DecorationImage(
                      image: conteudos[index].Img != null ?
                        FileImage(File(conteudos[index].Img)) :
                          AssetImage("images/person.png")
                  )
                ),
              ),
              Padding(
                padding: EdgeInsets.only(left: 5.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text(conteudos[index].Titulo ,
                      style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                    ),
                    Text(conteudos[index].Texto
                    ),


                  ],
                ),
              ),
            ],
          ),
        ),
      ),
      onTap: (){
        _showConteudoPage(conteudo: conteudos[index]);
      },
    );
  }
  Future<void> _showConteudoPage({Conteudo conteudo}) async {
    final reConteudo = await  Navigator.push(context,
        MaterialPageRoute(builder: (context)=> ConteudoDetalhes(conteudoDetalhe: conteudo,))
    );
        if (reConteudo !=null){
          if(conteudo !=null){
            await helper.UpdateConteudo(reConteudo);
        }else{
            await helper.SaveConteudo(reConteudo);
      }
    _getAll();
    }

  }
  void _getAll(){
    helper.GetAllConteudos().then((list){
      setState(() {
        conteudos=list;
      });
    });
  }
}
